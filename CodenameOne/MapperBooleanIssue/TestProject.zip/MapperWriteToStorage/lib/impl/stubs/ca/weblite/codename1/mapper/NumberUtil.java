package ca.weblite.codename1.mapper;


/**
 * 
 *  @author shannah
 */
public class NumberUtil {

	public NumberUtil() {
	}

	public static boolean isNumber(Object o) {
	}

	public static java.util.Date dateValue(Object o, com.codename1.l10n.DateFormat[] formats) {
	}

	public static java.util.Date dateValue(Object o, java.util.List formats) {
	}

	public static int intValue(Object o) {
	}

	public static byte byteValue(Object o) {
	}

	public static short shortValue(Object o) {
	}

	public static Integer boxedIntValue(Object o) {
	}

	public static Byte boxedByteValue(Object o) {
	}

	public static Character boxedCharacterValue(Object o) {
	}

	public static Short boxedShortValue(Object o) {
	}

	public static long longValue(Object o) {
	}

	public static Long boxedLongValue(Object o) {
	}

	public static double doubleValue(Object o) {
	}

	public static float floatValue(Object o) {
	}

	public static Double boxedDoubleValue(Object o) {
	}

	public static Float boxedFloatValue(Object o) {
	}

	public static boolean booleanValue(Object o) {
	}

	public static Boolean boxedBooleanValue(Object o) {
	}

	public static char charValue(Object o) {
	}

	public static Character boxedCharValue(Object o) {
	}

	public static double[] toDoubleArray(Object[] ints) {
	}

	public static float[] toFloatArray(Object[] ints) {
	}

	public static int[] toIntArray(Object[] ints) {
	}

	public static byte[] toByteArray(Object[] ints) {
	}

	public static char[] toCharArray(Object[] ints) {
	}

	public static boolean[] toBooleanArray(Object[] ints) {
	}
}
