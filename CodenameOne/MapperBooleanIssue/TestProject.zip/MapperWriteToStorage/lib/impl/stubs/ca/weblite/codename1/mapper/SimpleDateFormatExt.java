package ca.weblite.codename1.mapper;


/**
 * 
 *  @author shannah
 */
public class SimpleDateFormatExt extends com.codename1.l10n.SimpleDateFormat {

	public SimpleDateFormatExt(String pattern) {
	}

	@java.lang.Override
	public void applyPattern(String pattern) {
	}

	@java.lang.Override
	public java.util.Date parse(String source) {
	}
}
