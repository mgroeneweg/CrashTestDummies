package ca.weblite.codename1.mapper;


/**
 * 
 *  @author shannah
 */
public class Mapper {

	public Mapper() {
	}

	public Mappable readObject(java.util.Map map, Class klass) {
	}

	public java.util.List readObjects(java.util.Collection maps, Class klass) {
	}

	public void writeObject(Mappable o, java.util.Map output) {
	}

	public void writeObjects(java.util.Collection o, java.util.Collection output) {
	}

	public int readInt(java.util.Map map, String key) {
	}

	public double readDouble(java.util.Map map, String key) {
	}

	public long readLong(java.util.Map map, String key) {
	}

	public String readString(java.util.Map map, String key) {
	}

	public Mappable readMappable(java.util.Map map, String key, Class klass) {
	}
}
