/**
 * Your application code goes here
 */

package userclasses;

import com.codename1.io.Log;
import com.codename1.io.Storage;
import com.codename1.processing.Result;
import generated.StateMachineBase;
import com.codename1.ui.*; 
import com.codename1.ui.events.*;
import com.codename1.ui.util.Resources;
import com.itvisors.test.mapperstorage.data.DataClass;
import com.itvisors.test.mapperstorage.mirah.DataClassMapper;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Your name here
 */
public class StateMachine extends StateMachineBase {
    
    private DataClass data = null;
    private String storageName;
    
    public StateMachine(String resFile) {
        super(resFile);
        // do not modify, write code in initVars and initialize class members there,
        // the constructor might be invoked too late due to race conditions that might occur
    }
    
    /**
     * this method should be used to initialize variables instead of
     * the constructor/class scope to avoid race conditions
     */
    protected void initVars(Resources res) {
        storageName = "TestMapperWriteToStorage";
    }


    @Override
    protected void onMain_ButtonLoadAction(Component c, ActionEvent event) {

        Storage storageInstance = Storage.getInstance();
        if (storageInstance.exists(storageName)) {
            // Existing data in storage so load it.
            Object object = storageInstance.readObject(storageName);
            if (object != null) {
                HashMap dataMap = (HashMap) object;
                DataClassMapper dataClassMapper = new DataClassMapper();
                data = dataClassMapper.readMap(dataMap, DataClass.class);
                Form f = c.getComponentForm();
                findTextFieldString(c).setText(data.getStringValue());
                findTextFieldInt(c).setText("" + data.getIntValue());
                findOnOffSwitch(c).setValue(data.isBooleanValue());
                findTextFieldDouble(c).setText("" + data.getDoubleValue());
                findPickerDate(c).setDate(data.getDateValue());
                
            } else {
                // No existing data
                data = new DataClass();
            }
        } else {
            // No existing data
            data = new DataClass();
        }
    }
    
    @Override
    protected void onMain_ButtonSaveAction(Component c, ActionEvent event) {
    
        getFormData(c);
        
        Storage storageInstance = Storage.getInstance();
        DataClassMapper dataClassMapper = new DataClassMapper();
        Map dataMap = dataClassMapper.writeMap(data);        
        storageInstance.writeObject(storageName, dataMap);
        storageInstance.flushStorageCache();
        
    }

    @Override
    protected void onMain_ButtonJSONAction(Component c, ActionEvent event) {
    
        getFormData(c);

        DataClassMapper dataClassMapper = new DataClassMapper();
        Map jsonReadyMap = dataClassMapper.writeMap(data);
        Result jsonResult = Result.fromContent(jsonReadyMap);
        String json = jsonResult.toString();
        
        Log.p(json);
    
    }
    
    private void getFormData(Component c) {

        if (data == null) {
            data = new DataClass();
        }
        data.setStringValue(findTextFieldString(c).getText());
        data.setBooleanValue(findOnOffSwitch(c).isValue());
        data.setDateValue(findPickerDate(c).getDate());
        
        if (data.isBooleanValue()) {
            Log.p("Boolean value is true");
        } else {
            Log.p("Boolean value is false");
        }
        
        String intValueString = findTextFieldInt(c).getText();        
        int intValue;
        if (intValueString != null && intValueString.length() > 0) {
            intValue = Integer.parseInt(intValueString);
        } else {
            intValue = 0;
        }            
        data.setIntValue(intValue);
                        
        String doubleValueString = findTextFieldDouble(c).getText();        
        double doubleValue;
        if (doubleValueString != null && doubleValueString.length() > 0) {
            doubleValue = Double.parseDouble(doubleValueString);
        } else {
            doubleValue = 0;
        }            
        data.setDoubleValue(doubleValue);
        
    }
}
